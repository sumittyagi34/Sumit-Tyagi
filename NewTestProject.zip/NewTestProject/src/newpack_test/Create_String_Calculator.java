package newpack_test;

import java.util.Stack;

public class Create_String_Calculator {

    
    public static int evaluate(String expression) {
        if (expression == null || expression.isEmpty()) {
            return 0;
        }

       
        Stack<Integer> stack = new Stack<>();
        int currentNum = 0;
        char sign = '+';
        int n = expression.length();

        for (int i = 0; i < n; i++) {
            char c = expression.charAt(i);

            
            if (Character.isDigit(c)) {
                currentNum = currentNum * 10 + (c - '0');
            }

            
            if (!Character.isDigit(c) && c != ' ' || i == n - 1) {
                
                if (sign == '+') {
                    stack.push(currentNum);
                } else if (sign == '-') {
                    stack.push(-currentNum);
                } else if (sign == '*') {
                    stack.push(stack.pop() * currentNum);
                } else if (sign == '/') {
                    stack.push(stack.pop() / currentNum);
                }

                
                sign = c;
                currentNum = 0;
            }
        }

        
        int result = 0;
        for (int num : stack) {
            result += num;
        }

        return result;
    }

    public static void main(String[] args) {
        String expression1 = "3+2*2";
        System.out.println("Result of '" + expression1 + "' = " + evaluate(expression1));

        String expression2 = "3/2";
        System.out.println("Result of '" + expression2 + "' = " + evaluate(expression2));

        String expression3 = "3+5/2";
        System.out.println("Result of '" + expression3 + "' = " + evaluate(expression3));
    }
}

